# Richa Chaudhary — Portfolio

Responsive portfolio website built with HTML, CSS and JavaScript.

## Run in VS Code
1. Extract this ZIP and open the `richa_portfolio` folder in VS Code.
2. Open `index.html` in a browser, or use the VS Code Live Server extension and click **Go Live**.
3. No Node.js, Hugo, PHP, XAMPP or database is needed.

Your photo, Gmail and LinkedIn have already been added. The project section describes the Fake Image Detection System as an ongoing team project without claiming completed results.
